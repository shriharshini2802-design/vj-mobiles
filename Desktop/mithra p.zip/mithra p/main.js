function searchJob(){

let job=document.querySelectorAll("input")[0].value;

let location=document.querySelectorAll("input")[1].value;

if(job=="" || location==""){
alert("Please enter Job Title and Location");
}
else{
alert("Searching for "+job+" jobs in "+location);
}

}